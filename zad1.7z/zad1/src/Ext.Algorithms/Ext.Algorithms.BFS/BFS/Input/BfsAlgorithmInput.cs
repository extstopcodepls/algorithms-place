﻿using Ext.Algorithms.Core.Algorithms.Inputs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ext.Algorithms.BFS.BFS.Input
{
    public class BfsAlgorithmInput : IAlgorithmInput
    {
        public object Data { get; set; }
    }
}
