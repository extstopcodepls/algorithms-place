﻿using Ext.Algorithms.Core.Algorithms.Config;

namespace Ext.Algorithms.BFS.BFS.Config
{
    public class BfsAlgorithmConfig : IAlgorithmConfiguration
    {
    }
}
