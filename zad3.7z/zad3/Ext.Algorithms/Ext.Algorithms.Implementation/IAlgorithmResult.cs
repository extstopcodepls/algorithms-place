﻿namespace Ext.Algorithms.Implementation
{
    public interface IAlgorithmResult
    {
        string Result { get; }
    }
}